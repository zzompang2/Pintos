#include <stdio.h>
#include "tests/threads/tests.h"

void 
test_print_hello_world (void)
{
    printf ("hello, world!\n");
}